<?php
session_start();

// Include the database and hashing class
include(__DIR__ . '/Class/DB.php');
include(__DIR__ . '/Class/Hashing.php');
include(__DIR__ . '/Page/Class/Posts.php');

use DB\DBClass as Data;
use Hashing as Hash;
use Page\Posts as Post;

$Hash = new Hash;
$DB = new Data;
$DB::login("mysql:host=localhost;dbname=mhh;charset=utf8mb4", "root", "" );
$DB::connect();
// Check if the form was submitted

if (isset($_COOKIE['user'], $_COOKIE['passwd'])) {
    $query = $DB::query("SELECT * FROM userlogin WHERE username=?", $params=$_COOKIE['user']);
    if ($query[0]['UserName'] == $_COOKIE['user'] && $query[0]['UserPasswd'] == $_COOKIE['passwd']) {
        include('Page/index.php');
    }
}
else {
    ?>
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <title>login</title>
        <script src="JS/script.js"></script>
        <link rel="icon" href="IMG/cicada.png" type="image/png">
        <link rel="stylesheet" type="text/css" href="CSS/style.css">
    </head>
    <body>
    <form action="verify.php" method="post">
        <label for="username">Username: </label>
        <input type="text" name="username" id="username" placeholder="" />
        <label for="password">Password: </label>
        <input type="password" name="password" id="password" placeholder="" />
        <input type="submit" value="Submit" />
    </form>
    </body>
    </html>
    <?php
}
