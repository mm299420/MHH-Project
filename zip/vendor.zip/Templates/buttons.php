<?php
function btn() {
    echo '<form method="post" action="./index.php">
            <input type="image" src="../IMG/225-2258961_small-square-with-plus-sign-vector-plus-icon-svg.png" height="30" width="30"/>
        </form>';
}
function loginBTN() {
    echo '<form method="post" action="./index.php">
            <input type="submit" value="zip" height="30" width="30"/>
        </form>';
}
