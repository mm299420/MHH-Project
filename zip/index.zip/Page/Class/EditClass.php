<?php

namespace Page;

class EditClass
{

}