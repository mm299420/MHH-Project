function edit() {
    edit = document.getElementsByClassName("edit");
    window.open("Edit.html?w")
}