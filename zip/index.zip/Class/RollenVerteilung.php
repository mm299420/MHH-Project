<?php

namespace DB;

class RollenVerteilung
{

}