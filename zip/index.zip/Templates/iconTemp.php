<link rel="apple-touch-icon" sizes="180x180" href="IMG/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="IMG/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="IMG/favicon-16x16.png">
<link rel="manifest" href="IMG/manifest.json">
<link rel="mask-icon" href="IMG/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="IMG/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<meta name="HandheldFriendly" content="true" /><meta name="HandheldFriendly" content="true" />
<link rel="canonical" href="https://www.mhh.de/"/>
